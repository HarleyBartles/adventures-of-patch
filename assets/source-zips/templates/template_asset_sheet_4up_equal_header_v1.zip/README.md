# template_asset_sheet_4up_equal_header_v1

Generic reusable four-up asset-sheet template with four equal image slots.

The only baked wording in the PNG is the approved `ASSET SHEET` header. Subtitle/metadata and guidance areas are intentionally blank and described in `template_asset_sheet_4up_equal_header_v1.json` for compile-time fill.

Package contents:

- `template_asset_sheet_4up_equal_header_v1.png`
- `template_asset_sheet_4up_equal_header_v1.json`
- `README.md`

The JSON sidecar is the compile contract. Patch should verify geometry before repo publication.
