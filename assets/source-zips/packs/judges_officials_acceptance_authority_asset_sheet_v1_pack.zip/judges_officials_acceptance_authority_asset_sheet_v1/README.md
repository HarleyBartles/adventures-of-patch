# Judges and Officials / Acceptance Authority Asset Sheet

Deterministic no-credit compile from six Harley-accepted source images using a three-official / three-support-panel layout.
